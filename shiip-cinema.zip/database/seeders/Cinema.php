<?php

namespace Database\Seeders;

use App\Models\Cinema as ModelsCinema;
use Illuminate\Database\Seeder;

class Cinema extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        ModelsCinema::factory() -> times(3) -> create();
    }
}
