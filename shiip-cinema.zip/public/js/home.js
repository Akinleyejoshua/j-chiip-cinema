const goTo = (url) => {
    location.pathname = url;
}

const download = (url, event) => {
    location.pathname = `${url}/${event.target.id}`;
    // console.log(`${url}/${event.target.id}`)
}

const openTab = (page, e) => {
    $(`#${page}`).css({
        visibility: "visible",
    });
    $(e.target).css({
        background: "var(--red)",
        color: "white",
    })
}