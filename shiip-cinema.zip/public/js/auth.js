// $("#register").submit(event => {
//     event.preventDefault();
//     $.ajaxSetup({
//         headers: {
//             'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
//         }
//     });
//     $.ajax({
//         url: "/register",
//         type: "post",
//         dataType: "json",
//         data: $("#register").serialize(),
//         success: data => {
//             $(".text-danger").html("");
//             $("input").css({
//                 border: "none",
//             });
//             var success = data.responseJSON;
//             console.log(success);
//             console.log(data);
//             if (data[0][0] === 2) {
//                 $(".msg").html("<div class='alert-success'>Registerd!</div>");
//                 location.href = "/login";
//             } else if (data[0][0] === 1) {
//                 // $(".msg").html("<div class='alert-danger'>User already exist!</div>");
//                 $(document).find('[name=email]').after('<p class="text-danger">This email already exist</p>')
//                 $(document).find('input[name=email]').css({
//                     border: "1px solid var(--red)"
//                 })
//             }
//             else if (data[0][0] === 3) {
//                 // $(".msg").html("<div class='alert-danger'>User already exist!</div>");
//                 $(document).find('[name=username]').after('<p class="text-danger">This username already exist</p>')
//                 $(document).find('input[name=username]').css({
//                     border: "1px solid var(--red)"
//                 })
//             }

//         },
//         error: data => {
//             $(".text-danger").html("");
//             $("input").css({
//                 border: "none",
//             });
//             console.log(data)
//             console.log(data.responseJSON);

//             if (data.responseJSON !== undefined) {
//                 $.each(data.responseJSON.errors, function (field_name, error) {
//                     $(document).find('[name=' + field_name + ']').after('<p class="text-danger">' + error + '</p>')
//                     $(document).find('input[name=' + field_name + ']').css({
//                         border: "1px solid var(--red)"
//                     })
//                 })
//             }

//         },
//     })
// })

// $("#login").submit(event => {
//     event.preventDefault();
//     $.ajaxSetup({
//         headers: {
//             'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
//         }
//     });
//     $.ajax({
//         url: "/login",
//         type: "post",
//         dataType: "json",
//         data: $("#login").serialize(),
//         success: data => {
//             $(".text-danger").html("");
//             $("input").css({
//                 border: "none",
//             });
//             var success = data.responseJSON;
//             // console.log(success);
//             // console.log(data);
//             if (data[0][0] === 2) {
//                 $(".msg").html("<div class='alert-success'>Authenticated</div>");
//                 location.href = "/home";
//                 // history.back();
//             } else if (data[0][0] === 1) {
//                 // $(".msg").html("<div class='alert-danger'>User already exist!</div>");
//                 $(".msg").html('<p class="alert-danger">Wrong email/password</p>')
//                 $(document).find('input').css({
//                     border: "1px solid var(--red)"
//                 })
//             } else if (data[0][0] === 3){
//                 $(".msg").html('<p class="alert-danger">User does not exist</p>')
//                 $(document).find('input').css({
//                     border: "1px solid var(--red)"
//                 })
//             }

//         },
//         error: data => {
//             $(".text-danger").html("");
//             $("input").css({
//                 border: "none",
//             });
//             // console.log(data)
//             // console.log(data.responseJSON);

//             if (data.responseJSON !== undefined) {
//                 $.each(data.responseJSON.errors, function (field_name, error) {
//                     $(document).find('[name=' + field_name + ']').after('<p class="text-danger">' + error + '</p>')
//                     $(document).find('input[name=' + field_name + ']').css({
//                         border: "1px solid var(--red)"
//                     })
//                 })
//             }

//         },
//     })
// })