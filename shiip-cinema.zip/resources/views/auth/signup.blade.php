<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Shiip-Cinema | Signup</title>
    <!-- Fonts -->
    <!-- <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet"> -->
    <link rel="stylesheet" href="{{ asset('css/auth.css') }}">
    <link rel="stylesheet" href="{{ asset('font-awesome/css/all.css') }}">
    <!-- Styles -->

</head>

<body>
    <header>
        <nav>
            <div class="navbrand row">
                <h2>Shiip<span>Cinema</span>
                    <i class="fa fa-video"></i>
                </h2>
            </div>

            <div class="navbar">
                <!-- <a href="{{ url('/login') }}">Login <span class="fa fa-arrow-right"></span></a> -->
            </div>
        </nav>
    </header>

    <main>
        <div class="heading">
            <h3>Register Now!</h3>
        </div>
        <form method="post" id="register">
            @csrf
            @if (session('status'))
            <div class="msg alert-danger">

                <div class="text-error text-center mb-3">
                    <small>
                        {{ session('status') }}
                    </small>
                </div>
            </div>

            @endif
            <div class="item">

                <div class="input">
                    <input type="email" name="email" placeholder="Email Address" value="{{ old('email') }}">
                    @error("email")
                    <div class="msg alert-danger">
                        {{$message}}
                    </div>
                    @enderror
                </div>
                <div class="input">
                    <input type="text" name="username" placeholder="Your Username" value="{{ old('username') }}">
                    @error("username")
                    <div class="msg alert-danger">
                        {{$message}}
                    </div>
                    @enderror
                </div>
                <div class="input">
                    <input type="password" name="password" placeholder="Password">
                    @error("password")
                    <div class="msg alert-danger">
                        {{$message}}
                    </div>
                    @enderror
                </div>

            </div>
            <p id="actions">have account already? <a href="{{ url('/login') }}">Login <span class="fa fa-angle-right"></span></a></p>
            <button>Register <span class="fa fa-arrow-right"></span></button>
        </form>
    </main>

    <script src="{{ asset('js/jquery.min.js') }}"></script>
    <script src="{{ asset('js/auth.js') }}"></script>
</body>

</html>