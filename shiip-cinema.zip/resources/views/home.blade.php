<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Shiip-Cinema | Signup</title>
    <!-- Fonts -->
    <!-- <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet"> -->
    <link rel="stylesheet" href="{{ asset('css/home.css') }}">
    <link rel="stylesheet" href="{{ asset('font-awesome/css/all.css') }}">
    <!-- Styles -->

</head>

<body>
    <header>
        <nav>
            <div class="navbar">
                <!-- <a href="{{ url('/login') }}">Login <span class="fa fa-arrow-right"></span></a> -->
            </div>
        </nav>
    </header>

    <main class="row">
        <div class="sidebar">
            <div class="sidebar-top">
                <div class="navbrand row">
                    <h2>Shiip<span>Cinema</span>
                        <i class="fa fa-video"></i>
                    </h2>
                </div>
            </div>
            <div class="sidebar-actions">
                <button onclick="goTo('dashboard')" class="{{ Request::path() == 'dashboard' ? 'active' : '' }}"><i class="fa fa-chart-bar"></i> <p>Dashboard</p></button>
                <button onclick="goTo('')"><i class="fa fa-eye"></i> <p>View</p></button>
                <button onclick="goTo('movie')" class="{{ Request::path() == 'movie' ? 'active' : '' }}"><i class="fa fa-plus"></i> <p>Movie</p></button>
                <button onclick="goTo('cinema')" class="{{ Request::path() == 'cinema' ? 'active' : '' }}"><i class="fa fa-plus"></i> <p>Cinema</p></button>
                
                <!-- <button onclick="goTo('dashboard')" class="{{ Request::path() == 'dashboard' ? 'active' : '' }}"><i class="fa fa-chart-bar">&ThinSpace;<span class="fa fa-eye"></span></i> <p>Dashboard</p></button>
                <button onclick="goTo('movie')" class="{{ Request::path() == 'movie' ? 'active' : '' }}"><i class="fa fa-plus">&ThinSpace;<span class="fa fa-video"></span></i> <p>Movies</p></button>
                <button onclick="goTo('cinema')" class="{{ Request::path() == 'cinema' ? 'active' : '' }}"><i class="fa fa-plus">&ThinSpace;<span class="fa fa-film"></span></i> <p>Cinema</p></button> -->
            </div>
        </div>
        <div class="col main">
            <div class="welcome-msg">
                <p>Welcome, <b>{{auth() -> user() -> username}}</p>
                <form action="{{ url('logout') }}" method="get">
                    @csrf
                    <button class="fa fa-sign-out-alt"></button>
                </form>
            </div>
            <div class="body-content">
            @yield('body-content')
            </div>
        </div>
    </main>

    <script src="{{ asset('js/jquery.min.js') }}"></script>
    <script src="{{ asset('js/home.js') }}"></script>
</body>

</html>