<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Shiip-Cinema</title>
        <link rel="stylesheet" href="{{ asset('css/style.css') }}">
        <link rel="stylesheet" href="{{ asset('font-awesome/css/all.css') }}">
        <!-- Fonts -->
        <!-- <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet"> -->
    </head>
    <body>
        <header>
            <nav>
                <div class="navbrand row">
                    <a href="">
                    <h2>Shiip<span>Cinema</span>
                        <i class="fa fa-video"></i>
                    </h2>
                    </a>
                   
                </div>
            
                <button onclick="goTo('login')">Login</button>
            </nav>
        </header>

        <main>
            <h2>Our Movie Listing</h2>
            <div class="movies">
                <div class="items">
                    @if($movie -> count())
                    @foreach($movie as $key => $item)
                    <div class="item inner-items">
                        <div class="col">
                            <span class="fa fa-film"></span>
                        </div>
                        <div class="col info">
                            <h3>{{$item -> cinema}}</h3>
                            <p>{{$item -> name}}<p>
                            <p>{{ \Carbon\Carbon::parse($item ->  timestamp) -> diffForHumans() }}</p>
                            <p><i class="fa fa-map-marker"></i> {{$item -> location}}</p>
                        </div>
                        
                    </div>
                    @endforeach
                    @else
                    <h1>No Movie Listing for now, Come back later</h1>
                    @endif
                </div>
            </div>
        </main>

        <script src="{{ asset('js/jquery.min.js') }}"></script>
        <script src="{{ asset('js/home.js') }}"></script>
    </body>
</html>
