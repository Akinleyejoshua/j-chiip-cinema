@extends("home")

@section("body-content")
<div class="col">
    <div class="movies">
        <h2>Create Movie</h2>
        <form action="{{ url('create-movie') }}" method="post">
            @csrf
            @if (session('status'))
            <div class="msg alert-danger">

                <div class="text-error text-center mb-3">
                    <small>
                        {{ session('status') }}
                    </small>
                </div>
            </div>
            @endif
            @if (session('success'))
            <div class="msg alert-success">

                <div class="text-error text-center mb-3">
                    <small>
                        {{ session('success') }}
                    </small>
                </div>
            </div>
            @endif
            <div class="input">
                <input type="text" placeholder="Movie Name" name="name">
                @error("name")
                <div class="msg alert-danger">
                    {{$message}}
                </div>
                @enderror
            </div>
            <div class="input col">
                <!-- <label for="cinema">Cinema</label> -->
                @if($cinema -> count())
                <select name="cinema">
                    @foreach($cinema as $key => $items)
                    <option>{{$items -> name}}</option>
                    @endforeach      
                </select>
                @else
                <div class="row">
                    <input type="text" disabled placeholder="Create A Cinema First to Select one">
                    <a href="cinema">
                        <button class="row"><i class="fa fa-plus"></i>&ThinSpace;<p>Cinema</p></button>
                    </a>
                </div>
                @endif
                @error("location")
                <div class="msg alert-danger">
                    {{$message}}
                </div>
                @enderror
            </div>
            <div class="input">
                <input type="date" name="date">
                @error("date")
                <div class="msg alert-danger">
                    {{$message}}
                </div>
                @enderror
                <input type="time" name="time">
                @error("time")
                <div class="msg alert-danger">
                    {{$message}}
                </div>
                @enderror
            </div>
            <button>Create <i class="fa fa-plus"></i></button>
        </form>
    </div>
    @endsection