<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Shiip-Cinema | Signup</title>
    <!-- Fonts -->
    <!-- <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet"> -->
    <link rel="stylesheet" href="<?php echo e(asset('css/home.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('font-awesome/css/all.css')); ?>">
    <!-- Styles -->

</head>

<body>
    <header>
        <nav>
            <div class="navbar">
                <!-- <a href="<?php echo e(url('/login')); ?>">Login <span class="fa fa-arrow-right"></span></a> -->
            </div>
        </nav>
    </header>

    <main class="row">
        <div class="sidebar">
            <div class="sidebar-top">
                <div class="navbrand row">
                    <h2>Shiip<span>Cinema</span>
                        <i class="fa fa-video"></i>
                    </h2>
                </div>
            </div>
            <div class="sidebar-actions">
                <button onclick="goTo('dashboard')" class="<?php echo e(Request::path() == 'dashboard' ? 'active' : ''); ?>"><i class="fa fa-chart-bar"></i> <p>Dashboard</p></button>
                <button onclick="goTo('')"><i class="fa fa-eye"></i> <p>View</p></button>
                <button onclick="goTo('movie')" class="<?php echo e(Request::path() == 'movie' ? 'active' : ''); ?>"><i class="fa fa-plus"></i> <p>Movie</p></button>
                <button onclick="goTo('cinema')" class="<?php echo e(Request::path() == 'cinema' ? 'active' : ''); ?>"><i class="fa fa-plus"></i> <p>Cinema</p></button>
                
                <!-- <button onclick="goTo('dashboard')" class="<?php echo e(Request::path() == 'dashboard' ? 'active' : ''); ?>"><i class="fa fa-chart-bar">&ThinSpace;<span class="fa fa-eye"></span></i> <p>Dashboard</p></button>
                <button onclick="goTo('movie')" class="<?php echo e(Request::path() == 'movie' ? 'active' : ''); ?>"><i class="fa fa-plus">&ThinSpace;<span class="fa fa-video"></span></i> <p>Movies</p></button>
                <button onclick="goTo('cinema')" class="<?php echo e(Request::path() == 'cinema' ? 'active' : ''); ?>"><i class="fa fa-plus">&ThinSpace;<span class="fa fa-film"></span></i> <p>Cinema</p></button> -->
            </div>
        </div>
        <div class="col main">
            <div class="welcome-msg">
                <p>Welcome, <b><?php echo e(auth() -> user() -> username); ?></p>
                <form action="<?php echo e(url('logout')); ?>" method="get">
                    <?php echo csrf_field(); ?>
                    <button class="fa fa-sign-out-alt"></button>
                </form>
            </div>
            <div class="body-content">
            <?php echo $__env->yieldContent('body-content'); ?>
            </div>
        </div>
    </main>

    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/home.js')); ?>"></script>
</body>

</html><?php /**PATH C:\Users\AKINLEYE JOSHUA\Documents\Web Development\laravel\shiip-cinema\resources\views/home.blade.php ENDPATH**/ ?>