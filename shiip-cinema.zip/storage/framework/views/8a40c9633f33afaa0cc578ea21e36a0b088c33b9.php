


<?php $__env->startSection('body-content'); ?>
    <div class="col">
        <div class="items">
        <div class="item-bar row">
                <div class="col">
                <p>Cinema(s)</p>
                    <span class="fa fa-film"></span>
                </div>
                <h2><?php echo e($cinema -> count()); ?></h2>
            </div>
            <div class="item-bar row">
                <div class="col">
                <p>Movie(s)</p>
                    <span class="fa fa-video"></span>
                </div>
                <h2><?php echo e($movie -> count()); ?></h2>
            </div>
            <div class="item-bar row">
                <div class="col">
                <p>Users(s)</p>
                    <span class="fa fa-users"></span>
                </div>
                <h2><?php echo e($user -> count()); ?></h2>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\AKINLEYE JOSHUA\Documents\Web Development\laravel\shiip-cinema\resources\views/dashboard.blade.php ENDPATH**/ ?>