

<?php $__env->startSection("body-content"); ?>
<div class="col">
    <div class="movies">
        <h2>Create Movie</h2>
        <form action="<?php echo e(url('create-movie')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php if(session('status')): ?>
            <div class="msg alert-danger">

                <div class="text-error text-center mb-3">
                    <small>
                        <?php echo e(session('status')); ?>

                    </small>
                </div>
            </div>
            <?php endif; ?>
            <?php if(session('success')): ?>
            <div class="msg alert-success">

                <div class="text-error text-center mb-3">
                    <small>
                        <?php echo e(session('success')); ?>

                    </small>
                </div>
            </div>
            <?php endif; ?>
            <div class="input">
                <input type="text" placeholder="Movie Name" name="name">
                <?php $__errorArgs = ["name"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="msg alert-danger">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="input col">
                <!-- <label for="cinema">Cinema</label> -->
                <?php if($cinema -> count()): ?>
                <select name="cinema">
                    <?php $__currentLoopData = $cinema; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option><?php echo e($items -> name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>      
                </select>
                <?php else: ?>
                <div class="row">
                    <input type="text" disabled placeholder="Create A Cinema First to Select one">
                    <a href="cinema">
                        <button class="row"><i class="fa fa-plus"></i>&ThinSpace;<p>Cinema</p></button>
                    </a>
                </div>
                <?php endif; ?>
                <?php $__errorArgs = ["location"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="msg alert-danger">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="input">
                <input type="date" name="date">
                <?php $__errorArgs = ["date"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="msg alert-danger">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <input type="time" name="time">
                <?php $__errorArgs = ["time"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="msg alert-danger">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <button>Create <i class="fa fa-plus"></i></button>
        </form>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make("home", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\AKINLEYE JOSHUA\Documents\Web Development\laravel\shiip-cinema\resources\views/movie.blade.php ENDPATH**/ ?>