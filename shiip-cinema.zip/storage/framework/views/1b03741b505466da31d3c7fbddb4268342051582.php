

<?php $__env->startSection('body-content'); ?>
    <div class="col">
        <div class="cinema">
        <h2>Create Cinema</h2>
        <form action="<?php echo e(url('create-cinema')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php if(session('status')): ?>
            <div class="msg alert-danger">

                <div class="text-error text-center mb-3">
                    <small>
                        <?php echo e(session('status')); ?>

                    </small>
                </div>
            </div>
            <?php endif; ?>
            <?php if(session('success')): ?>
            <div class="msg alert-success">

                <div class="text-error text-center mb-3">
                    <small>
                        <?php echo e(session('success')); ?>

                    </small>
                </div>
            </div>
            <?php endif; ?>
            <div class="input">
                <input type="text" placeholder="Cinema Name" name="name">
                <?php $__errorArgs = ["name"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="msg alert-danger">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="input">
                <input type="text" placeholder="Cinema Location" name="location">
                <?php $__errorArgs = ["location"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="msg alert-danger">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <button>Create <i class="fa fa-plus"></i></button>
            </form>

        </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("home", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\AKINLEYE JOSHUA\Documents\Web Development\laravel\shiip-cinema\resources\views/cinema.blade.php ENDPATH**/ ?>