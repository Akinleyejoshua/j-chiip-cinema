<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Shiip-Cinema | Login</title>
    <!-- Fonts -->
    <!-- <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet"> -->
    <link rel="stylesheet" href="<?php echo e(asset('css/auth.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('font-awesome/css/all.css')); ?>">
    <!-- Styles -->

</head>

<body>
    <header>
        <nav>
            <div class="navbrand row">
                <h2>Shiip<span>Cinema</span> 
                <i class="fa fa-video"></i>
            </h2>
            </div>

            <div class="navbar">
                <!-- <a href="<?php echo e(url('/login')); ?>">Login <span class="fa fa-arrow-right"></span></a> -->
            </div>
        </nav>
    </header>

    <main>
        <div class="heading">
            <h3>Login Now!</h3>
        </div>
        <form method="post" id="login">
            <?php echo csrf_field(); ?>
            <?php if(session('status')): ?>
            <div class="msg alert-danger">

                <div class="text-error text-center mb-3">
                    <small>
                        <?php echo e(session('status')); ?>

                    </small>
                </div>
            </div>

            <?php endif; ?>
            <div class="item">
                <div class="input">
                    <input type="email" name="email" placeholder="Email Address"  value="<?php echo e(old('email')); ?>">
                    <?php $__errorArgs = ["email"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="msg alert-danger">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
               
                <div class="input">
                    <input type="password" name="password" placeholder="Password"  value="<?php echo e(old('password')); ?>">
                    <?php $__errorArgs = ["password"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="msg alert-danger">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
               
            </div>
            <p id="actions">Dont have an account? <a href="<?php echo e(url('/register')); ?>">Register <span class="fa fa-angle-right"></span></a></p>
            <button>Signin <span class="fa fa-arrow-right"></span></button>
        </form>
    </main>

    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/auth.js')); ?>"></script>
</body>

</html><?php /**PATH C:\Users\AKINLEYE JOSHUA\Documents\Web Development\laravel\shiip-cinema\resources\views/auth/login.blade.php ENDPATH**/ ?>