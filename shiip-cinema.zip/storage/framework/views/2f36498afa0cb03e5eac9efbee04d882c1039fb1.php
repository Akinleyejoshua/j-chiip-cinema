<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Shiip-Cinema</title>
        <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('font-awesome/css/all.css')); ?>">
        <!-- Fonts -->
        <!-- <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet"> -->
    </head>
    <body>
        <header>
            <nav>
                <div class="navbrand row">
                    <a href="">
                    <h2>Shiip<span>Cinema</span>
                        <i class="fa fa-video"></i>
                    </h2>
                    </a>
                   
                </div>
            
                <button onclick="goTo('login')">Login</button>
            </nav>
        </header>

        <main>
            <h2>Our Movie Listing</h2>
            <div class="movies">
                <div class="items">
                    <?php if($movie -> count()): ?>
                    <?php $__currentLoopData = $movie; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item inner-items">
                        <div class="col">
                            <span class="fa fa-film"></span>
                        </div>
                        <div class="col info">
                            <h3><?php echo e($item -> cinema); ?></h3>
                            <p><?php echo e($item -> name); ?><p>
                            <p><?php echo e(\Carbon\Carbon::parse($item ->  timestamp) -> diffForHumans()); ?></p>
                            <p><i class="fa fa-map-marker"></i> <?php echo e($item -> location); ?></p>
                        </div>
                        
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <h1>No Movie Listing for now, Come back later</h1>
                    <?php endif; ?>
                </div>
            </div>
        </main>

        <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/home.js')); ?>"></script>
    </body>
</html>
<?php /**PATH C:\Users\AKINLEYE JOSHUA\Documents\Web Development\laravel\shiip-cinema\resources\views/welcome.blade.php ENDPATH**/ ?>