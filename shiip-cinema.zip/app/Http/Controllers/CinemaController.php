<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Interfaces\CinemaInterface;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Response;
use App\Repositories\CinemaRepository;

class CinemaController extends Controller
{
    //

    private CinemaInterface $cinemaRepository;

    public function __construct(CinemaInterface $cinemaRepository)
    {   
        $this -> cinemaRepository = $cinemaRepository;

    }

    public function index() {
        return response() -> json([
            "data" => $this -> cinemaRepository -> getAll()
        ]);
    }

    public function create_cinema(Request $request){

        // dd($request -> all());

        $this -> validate($request, [
            "name" => "required",
            "location" => "required"
        ]);

        $exist = $this -> cinemaRepository -> checkIfExist($request->only("name", "location"));
        if ($exist) {
            return back() -> with("status", "Cinema record exist!");
        } else {
            if($this -> cinemaRepository -> createCinema($request->only("name", "location"))){
                return back() -> with("success", "Cinema Created");
            }

        }

    }
}
