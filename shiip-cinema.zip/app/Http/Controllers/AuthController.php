<?php

namespace App\Http\Controllers;

use App\Interfaces\UserInterface;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;

class AuthController extends Controller

{
    public function login()
    {
        return view("auth.login");
    }

    public function signup()
    {
        return view("auth.signup");
    }

    public UserInterface $userRepository;

    public function __construct(UserInterface $userRepository)
    {
        $this->userRepository = $userRepository;
        $this->middleware(["guest"]);
    }

    public function register(Request $request)
    {

        $this->validate($request, [
            // "bank_name" => "required|max:255",
            "username" => "required|max:255",
            "email" => "required|email|max:255",
            "password" => "required",
        ]);


        $checkIfExist = $this->userRepository->checkIfExist($request->email);
        if ($checkIfExist) {
            Session::flash("status", "Account already exist");
            return back()->withInput();
        } else {
            $new_user = $this->userRepository->createUser($request->all());
            if ($new_user) {
                return redirect("dashboard");
            } else {
                Session::flash("status", "Oops, somthing went wrong");
                return back()->withInput();
            }
        }
    }

    public function signin(Request $request)
    {
        $this->validate($request, [
            // "bank_name" => "required|max:255",
            "email" => "required|email|max:255",
            "password" => "required",
        ]);

        $checkIfExist = $this->userRepository->checkIfExist($request->email);
        if (!$checkIfExist) {
            Session::flash("status", "Account does not exist");
            return back()->withInput();
        } else if ($this->userRepository->checkIfMatch($request->email, $request->password)) {
            $user = User::where("email", "=", $request -> email) -> where("password", "=", $request -> password) -> first();
            auth() -> login($user);
            return redirect("dashboard");
        } else {
            Session::flash("status", "Wrong email/passord");
            return back()->withInput();
        }
    }

}
