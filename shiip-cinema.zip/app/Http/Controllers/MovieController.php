<?php

namespace App\Http\Controllers;

use App\Interfaces\MovieInterface;
use App\Repositories\MovieRepository;
use Illuminate\Http\Request;

class MovieController extends Controller
{
    private MovieInterface $movieRepository;

    public function __construct(MovieInterface $movieRepository)
    {
        $this -> movieRepository = $movieRepository;
    }

    public function create_movie(Request $request) {
        $this -> validate($request, [
            "name" => "required",
            "cinema" => "required",
            "date" => "required",
            "time" => "required",
        ]);

        $request["timestamp"] = $request -> date." ".$request -> time;
        
        $exits = $this ->movieRepository->checkIfExist($request->only("cinema", "timestamp"));
        if ($exits) {
            return back() -> with("status", "Cannot have same movie in the same cinema & time");
        } else {
            if ($this -> movieRepository -> createMovie($request -> all())){
                return back() -> with("success", "Movie Created");
            }
        }
    }
}
