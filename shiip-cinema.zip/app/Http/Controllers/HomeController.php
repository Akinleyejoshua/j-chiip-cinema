<?php

namespace App\Http\Controllers;

use App\Interfaces\CinemaInterface;
use App\Interfaces\MovieInterface;
use App\Interfaces\UserInterface;
use App\Models\Cinema;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function home(){
        return redirect("dashboard");
    }

    public function __construct()
    {
        $this -> middleware(["auth"]);
    }

    public function cinema(){
            return view("cinema");
    }

    public function movies(CinemaInterface $cinemaInterface){
        $cinemaInterface  = $cinemaInterface -> getAll();
        // dd($cinemaInterface);

        return view("movie", [
            "cinema" => $cinemaInterface
        ]);
    }

    public function dashboard(UserInterface $userRepository, CinemaInterface $cinemaRepository, MovieInterface $movieRepository){
        $user = $userRepository -> getAll();
        $movie = $movieRepository -> getAll();
        $cinema = $cinemaRepository -> getAll();

        return view("dashboard", [
            "user" => $user,
            "movie" => $movie,
            "cinema" => $movie,
        ]);
    }
}
