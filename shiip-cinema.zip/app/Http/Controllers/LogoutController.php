<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class LogoutController extends Controller
{
    public function logout(){
        // dd(null);
        auth() -> logout();
        return redirect("login");
    }

}
