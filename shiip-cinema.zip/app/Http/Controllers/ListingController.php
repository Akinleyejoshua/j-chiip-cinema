<?php

namespace App\Http\Controllers;

use App\Interfaces\CinemaInterface;
use App\Interfaces\MovieInterface;
use App\Interfaces\UserInterface;
use Illuminate\Http\Request;

class ListingController extends Controller
{
    public function listing_page(UserInterface $userRepository, CinemaInterface $cinemaRepository, MovieInterface $movieRepository){
        $user = $userRepository -> getAll();
        $movie = $movieRepository -> getAll();
        $cinema = $cinemaRepository -> getAll();

        return view("welcome", [
            "user" => $user,
            "movie" => $movie,
            "cinema" => $movie,
        ]);
    }
}
