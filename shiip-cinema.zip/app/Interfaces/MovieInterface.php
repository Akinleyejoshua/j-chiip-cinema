<?php

namespace App\Interfaces;

interface MovieInterface {
    public function getAll();
    public function getById($id);
    public function createMovie($data);
    public function checkIfExist($data);
}