<?php

namespace App\Interfaces;

interface UserInterface {
    public function getAll();
    public function getById($id);
    public function createUser($data);
    public function checkIfExist($data);
    public function checkIfMatch($email, $password);
}