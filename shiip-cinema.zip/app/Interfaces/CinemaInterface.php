<?php

namespace App\Interfaces;

interface CinemaInterface {
    public function getAll();
    public function getById($id);
    public function createCinema($data);
    public function checkIfExist($data);

}