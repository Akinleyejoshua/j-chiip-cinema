<?php

namespace App\Providers;

use App\Interfaces\CinemaInterface;
use App\Repositories\CinemaRepository;
use Illuminate\Support\ServiceProvider;

class CinemaRepositoryInterface extends ServiceProvider
{
    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        $this -> app -> bind(CinemaInterface::class, CinemaRepository::class);
    }

    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
        //
    }
}
