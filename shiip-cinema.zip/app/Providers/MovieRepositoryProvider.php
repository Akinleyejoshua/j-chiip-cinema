<?php

namespace App\Providers;

use App\Interfaces\MovieInterface;
use App\Repositories\MovieRepository;
use Illuminate\Support\ServiceProvider;

class MovieRepositoryProvider extends ServiceProvider
{
    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        $this -> app -> bind(MovieInterface::class, MovieRepository::class);
        
    }

    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
        //
    }
}
