<?php

namespace App\Repositories;

use App\Interfaces\UserInterface;

use App\Models\User;

class UserRepository implements UserInterface {
    public function getAll(){
        return User::all();
    }

    public function getById($id){
        return User::findOrFail($id);
    }

    public function createUser($details){
        return User::create($details);
    }

    public function checkIfExist($data)
    {
        return User::where("email", "=" ,$data) -> first();
    }

    public function checkIfMatch($email, $password)
    {
        return User::where("email", "=", $email) -> where("password", "=", $password) -> count();
    }
}