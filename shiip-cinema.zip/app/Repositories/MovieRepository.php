<?php

namespace App\Repositories;

use App\Interfaces\MovieInterface;
use App\Models\Cinema;
use App\Models\Movie;

class MovieRepository implements MovieInterface {
    public function getAll(){
        return Movie::all();
    }

    public function getById($id){
        return Movie::findOrFail($id);
    }

    public function createMovie($details){
        $cinema = Cinema::where("name", "=", $details['cinema'])-> first();
        $cinema -> location;
        $details["location"] = $cinema -> location;
        // dd($details);
        return Movie::create($details);
    }

    public function checkIfExist($data){        
        return Movie::where("cinema", "=", $data['cinema']) -> where("timestamp", "=", $data['timestamp']) -> first();
    }
}