<?php

namespace App\Repositories;

use App\Interfaces\CinemaInterface;

use App\Models\Cinema;

class CinemaRepository implements CinemaInterface {
    public function getAll(){
        return Cinema::all();
    }

    public function getById($id){
        return Cinema::findOrFail($id);
    }

    public function createCinema($details){
        return Cinema::create($details);
    }

    public function checkIfExist($data){
        return Cinema::where("location", "=", $data['location']) -> where("name", "=", $data['name']) -> first();
    }
}