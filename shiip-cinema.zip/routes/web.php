<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\CinemaController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\ListingController;
use App\Http\Controllers\LogoutController;
use App\Http\Controllers\MovieController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::post("/logout", [AuthController::class, "logout_user"]) -> name("logout");
Route::post("/register", [AuthController::class, "register"]) -> name("register");
Route::post("/login", [AuthController::class, "signin"]) -> name("login");
Route::post("/create-cinema", [CinemaController::class, "create_cinema"]) -> name("create-cinema") -> middleware(["auth"]);
Route::post("/create-movie", [MovieController::class, "create_movie"]) -> name("create-movie") -> middleware(["auth"]);

Route::get('/', [ListingController::class, "listing_page"]) -> name("");
Route::get("/login", [AuthController::class, "login"]) -> name("login");
Route::get("/register", [AuthController::class, "signup"]) -> name("register");
Route::get("/home", [HomeController::class, "home"]) -> name("home");
Route::get("/cinema", [HomeController::class, "cinema"]) -> name("cinema");
Route::get("/movie", [HomeController::class, "movies"]) -> name("movie");
Route::get("/dashboard", [HomeController::class, "dashboard"]) -> name("dashboard");
Route::get("/logout", [LogoutController::class, "logout"]) -> name("logout");
